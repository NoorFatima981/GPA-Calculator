import 'package:flutter/material.dart';

class CourseDetail extends StatefulWidget {
  String? DegreeName;
  CourseDetail(String s){
    DegreeName=s;
  }


  @override
  State<CourseDetail> createState() => _CourseDetailState();
}

class _CourseDetailState extends State<CourseDetail> {
  final TextEditingController _CourseName = TextEditingController();
  List<String> grades = [];

  List<String> courseNames = [];
  String? selectedGrade;
  var gradesValue = [
    "A+",
    "A",
    "B+",
    "B",
    "C+",
    "C",
    "D+",
    "D",
  ];
  void showGradeDropDown() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Container(
            height: 500,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Text(
                    "Add Course Details",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xff2B5FB2),
                    ),
                  ),
                ),
                SizedBox(height: 16),
                TextField(
                  controller: _CourseName,
                  decoration: InputDecoration(
                    labelText: 'Course Name',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  decoration: InputDecoration(
                    labelText: 'Grade',
                    border: OutlineInputBorder(),
                  ),
                  value: selectedGrade,
                  hint: Text("Select Grade"),
                  onChanged: (String? value) {
                    setState(() {
                      selectedGrade = value;
                    });
                  },
                  items: gradesValue.map((String grade) {
                    return DropdownMenuItem<String>(
                      value: grade,
                      child: Text(grade),
                    );
                  }).toList(),
                ),
                Expanded(
                    child: SizedBox()),
                Center(
                  child: Container(
                    height: 77,
                    width: 354,
                    child: ElevatedButton(
                      onPressed: () {
                        if(_CourseName.text.isNotEmpty && selectedGrade!.isNotEmpty){
                          setState(() {
                            courseNames.add(_CourseName.text);
                            grades.add(selectedGrade!);
                            _CourseName.clear();
                            selectedGrade = null;
                          });
                        }
                        else{
                          ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text("Enter course name and Select grade"),
                              ));
                        }
                        Navigator.pop(context);
                      },
                      child: Text("Add",style: TextStyle(color: Colors.white,fontSize: 24),),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xff2B5FB2),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
  void _ShowDialogue(){
    showDialog(
        context: context, builder: (BuildContext context){
      return AlertDialog(
        title: Text("GPA Score",
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xff2B5FB2),
            fontSize: 32,
            fontWeight: FontWeight.w500
        ),),
        content: Container(
          height: 354,
          width: 453,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text("Your total GPA score of the degree program ${widget.DegreeName} is",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black,fontSize: 16,fontWeight: FontWeight.w400),),
              SizedBox(height: 20,),
              Text("${CalculateGpa().toStringAsFixed(2)}", style: TextStyle(color:Color(0xff2B5FB2),fontSize: 20,fontWeight: FontWeight.w700),),
            ],
          ),
        ),
        actions: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 77,
                width: 180,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                ),
                child: ElevatedButton(onPressed: (){
                  Navigator.of(context).pop();
                },
                    style: ElevatedButton.styleFrom(backgroundColor: Color(0xff22A92F),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        )
                    ),
                    child: Text("Okay",style: TextStyle(color: Colors.white,fontSize: 24,fontWeight: FontWeight.w600),)),
              ),
            ],
          )
        ],
      );

    });
  }
  double CalculateGpa() {
    Map<String, double> gradeValues = {
      "A+": 4.0,
      "A": 4.0,
      "A-": 3.7,
      "B+": 3.3,
      "B": 3.0,
      "B-": 2.7,
      "C+": 2.3,
      "C": 2.0,
      "C-": 1.7,
      "D+": 1.3,
      "D": 1.0,
      "D-": 0.7,
      "F": 0.0,
    };

    double totalGpa = 0.0;
    for (String grade in grades) {
      totalGpa += gradeValues[grade] ?? 0.0;
    }

    double overallGpa = totalGpa / grades.length;
    if(overallGpa!=0){
      return overallGpa;
    }
    else {

      return 0;
    }
    return overallGpa;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 55.0),
            child: Text(
              "Course Details",
              style: TextStyle(
                color: Color(0xff2B5FB2),
                fontSize: 20,
                fontWeight: FontWeight.w500,
                fontFamily: "Poppins",
              ),
            ),
          ),
          Expanded(
            child: Visibility(
              visible: courseNames.isNotEmpty && grades.isNotEmpty,
              child: ListView.builder(
                itemCount: courseNames.length,
                itemBuilder: (context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(left: 38.0,right: 38,top: 10),
                    child: Container(
                      height: 75,
                      width: 254,
                      decoration: BoxDecoration(
                        border: Border.all(color: Color(0xff2B5FB2), width: 2), // Add this line
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: Text(
                              courseNames[index],
                              style: TextStyle(
                                color: Color(0xff2B5FB2),
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                fontFamily: "Poppins",
                              ),
                            ),
                          ),
                          SizedBox(height: 8),
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: Text(
                              "Grade: ${grades[index]}",
                              style: TextStyle(
                                color: Color(0xff2B5FB2),
                                fontSize: 14,
                                fontWeight: FontWeight.w400,
                                fontFamily: "Poppins",
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
              replacement: Padding(
                padding: const EdgeInsets.all(30.0),
                child: Center(child: Align(
                  alignment: Alignment.center,
                  child: Text("Write About Your Courses and Grades ",
                    style: TextStyle(color:Color(0xff2B5FB2),fontSize: 30,fontWeight: FontWeight.w400),),
                )),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                height: 77,
                width: 177,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                ),
                child: ElevatedButton(
                  onPressed: showGradeDropDown,

                  child: Text(
                    "Add",
                    style: TextStyle(color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    backgroundColor: Color(0xff2B5FB2),

                  ),
                ),
              ),
              Container(
                height: 77,
                width: 177,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                ),
                child: ElevatedButton(
                  onPressed: _ShowDialogue,
                  child: Text(
                    "Calculate",
                    style: TextStyle(color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    backgroundColor: Color(0xff22A92F),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 20,)
        ],
      ),
    );
  }
}