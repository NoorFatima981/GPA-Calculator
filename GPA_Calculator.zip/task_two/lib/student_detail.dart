import 'package:flutter/material.dart';
import 'package:task_two/course_detail.dart';

class Studentdetail extends StatefulWidget {
  const Studentdetail({super.key});
  @override
  State<Studentdetail> createState() => _StudentdetailState();
}
class _StudentdetailState extends State<Studentdetail> {
  TextEditingController _Name=new TextEditingController();
  var DegreePrograms=["BSCS","BSSE","BSIT"];
  String? SelectedProgram;
  String? Gender;
  var GenderType=["Male","Female"];
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.white,
        body: Container(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 15.0),
                child: Text("Student Details",style:
                TextStyle(color: Color(0xff2B5FB2)
                    ,fontSize: 20,fontWeight: FontWeight.w500,
                    fontFamily: "Poppins"),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 20.0,right: 20,left: 20,bottom: 10),
                child: Container(
                  height: 55,
                  width: 354,
                  child: TextFormField(
                    controller: _Name,
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(
                          color:  Color(0xff2B5FB2),
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(
                          color:  Color(0xff2B5FB2),
                        ),
                      ),
                      hintText: "Student Name",
                      fillColor: Colors.white,
                      filled: true,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20.0,right: 20),
                child: Container(
                  height: 55,
                  width: 354,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.white,
                    border: Border.all(color:Color(0xff2B5FB2),
                        width: 1),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(

                      value: SelectedProgram,
                      hint: Text("  Degree Program"),
                      onChanged: (String? Value){
                        setState(() {
                          SelectedProgram=Value;
                        });
                      },
                      items: DegreePrograms.map((String Program){
                        return DropdownMenuItem(
                          child: Text("  ${Program}"),
                          value: Program,
                        );
                      }).toList(),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 70.0,top: 10),
                child: Row(

                  children: [
                    RadioMenuButton(value: GenderType[0], groupValue: Gender, onChanged: (value){
                      setState(() {
                        Gender=value;
                      });
                    }, child: Text("Male"),
                    ),
                    RadioMenuButton(value: GenderType[1], groupValue: Gender, onChanged: (value){
                      setState(() {
                        Gender=value;
                      });
                    }, child: Text("Female")),
                  ],
                ),
              ),
              Expanded(child: SizedBox()),
              Container(
                height: 75,
                width: 354,
                decoration: BoxDecoration(

                    borderRadius: BorderRadius.circular(10)
                ),

                child:
                ElevatedButton(onPressed: (){
                  if (SelectedProgram!= null && _Name.text.isNotEmpty) {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context)=>CourseDetail(SelectedProgram!)));
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a degree program and Enter your name',
                      textAlign: TextAlign.center,)));
                  }
                }, child:const Text("Next",style:
                TextStyle(color: Colors.white
                    ,fontSize: 24,fontWeight: FontWeight.w600,
                    fontFamily: "Poppins"),),
                    style:ElevatedButton.styleFrom(
                        backgroundColor: Color(0xff2B5FB2),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)
                        )
                    )
                ),
              ),
              SizedBox(height: 20,)
            ],
          ),
        ),
      ),
    );
  }
}