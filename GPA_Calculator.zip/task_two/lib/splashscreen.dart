import 'dart:async';
import 'package:flutter/material.dart';
import 'package:task_two/student_detail.dart';


class splashscreen extends StatefulWidget {
  const splashscreen({super.key});

  @override
  State<splashscreen> createState() => _splashState();
}

class _splashState extends State<splashscreen> {
  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds:3),
            () =>
            Navigator.push(
              context, MaterialPageRoute(builder: (context) => Studentdetail()),
            ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(

        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [ Image.asset("assets/images/Rectangle 1.png"),
              const Padding(
                padding: EdgeInsets.only(top: 15.0),
                child: Text("GPA CALCULATOR",
                  style: TextStyle(
                    color: Color(0xFF2B5FB2),
                  ),
                ),
              ),
            ]
        ),
      ),
    );
  }
}

