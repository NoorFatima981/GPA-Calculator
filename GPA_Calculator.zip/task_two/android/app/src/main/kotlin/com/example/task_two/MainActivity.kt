package com.example.task_two

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
